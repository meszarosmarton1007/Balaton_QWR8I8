export const environment = {
  firebase: {
    projectId: 'webfejl-2022-dd474',
    appId: '1:859776067209:web:3b9ffc8cbed176e87b4858',
    storageBucket: 'webfejl-2022-dd474.appspot.com',
    apiKey: 'AIzaSyBO5P1yGv4pPrrdtUJS9rZRRgv6kUfYHlo',
    authDomain: 'webfejl-2022-dd474.firebaseapp.com',
    messagingSenderId: '859776067209',
    measurementId: 'G-CQ0KXNV9CD',
  },
  production: true
};
