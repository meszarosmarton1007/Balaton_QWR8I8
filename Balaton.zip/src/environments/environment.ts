// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'webfejl-2022-dd474',
    appId: '1:859776067209:web:3b9ffc8cbed176e87b4858',
    storageBucket: 'webfejl-2022-dd474.appspot.com',
    apiKey: 'AIzaSyBO5P1yGv4pPrrdtUJS9rZRRgv6kUfYHlo',
    authDomain: 'webfejl-2022-dd474.firebaseapp.com',
    messagingSenderId: '859776067209',
    measurementId: 'G-CQ0KXNV9CD',
  },
  production: false,
  hostUrl: 'http://localhost:4200'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
