export interface Comment {
    id: string;
    username: string;
    comment: string;
    date: number;
    imageId?: string;
}